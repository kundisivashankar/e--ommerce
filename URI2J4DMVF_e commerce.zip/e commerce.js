const productList = document.getElementById('product-list');

fetch('https://products-api-2ttf.onren.com/api/products')
    .then(response => {
        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }
        return response.json();
    })
    .then(data => {
        data.forEach(product => {
            const productItem = document.createElement('li');
            productItem.innerHTML = `
                    <h3>${product.name}</h3>
                    <p>Price: $${product.price}</p>
                    <p>Description: ${product.description}</p>
                `;
            productList.appendChild(productItem);
        });
    })
    .catch(error => {
        console.error('Error fetching data:', error);
    });